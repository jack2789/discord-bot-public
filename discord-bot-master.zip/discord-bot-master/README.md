# discord-bot
Discord bot with various functions
